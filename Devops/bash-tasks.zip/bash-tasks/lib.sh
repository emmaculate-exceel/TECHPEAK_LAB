# Shared helpers for all check.sh files
PASS=0; FAIL=0
ok()  { echo "  PASS: $1"; PASS=$((PASS+1)); }
bad() { echo "  FAIL: $1"; FAIL=$((FAIL+1)); }
expect_eq()       { [[ "$2" == "$3" ]] && ok "$1" || bad "$1 (expected '$3', got '$2')"; }
expect_contains() { [[ "$2" == *"$3"* ]] && ok "$1" || bad "$1 (missing '$3')"; }
expect_file()     { [[ -e "$2" ]] && ok "$1" || bad "$1 (missing $2)"; }
expect_no_file()  { [[ ! -e "$2" ]] && ok "$1" || bad "$1 (should not exist: $2)"; }
summary() { echo "Result: $PASS passed, $FAIL failed"; [[ $FAIL -eq 0 ]]; }
# prep TASKDIR SCRIPT -> sets SCRIPT (absolute) and moves into a fresh temp workspace
prep() {
  SCRIPT=$(realpath "$2") || { echo "Script not found: $2"; exit 1; }
  [[ -f $SCRIPT ]] || { echo "Script not found: $2"; exit 1; }
  WORK=$(mktemp -d); cd "$WORK"
  [[ -f "$1/setup.sh" ]] && bash "$1/setup.sh" >/dev/null
  echo "Checking $(basename "$SCRIPT") ..."
}
