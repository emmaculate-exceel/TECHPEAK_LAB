#!/usr/bin/env bash
secret="${SECRET:-$((RANDOM % 100 + 1))}"
guesses=0
echo "I'm thinking of a number between 1 and 100."
while true; do
  read -r -p "Your guess: " guess || { echo; echo "Goodbye!"; exit 1; }
  if ! [[ $guess =~ ^[0-9]+$ ]]; then
    echo "Please enter a number."
    continue
  fi
  guesses=$((guesses + 1))
  if (( guess < secret )); then
    echo "Too low!"
  elif (( guess > secret )); then
    echo "Too high!"
  else
    echo "Correct! You took $guesses guesses."
    break
  fi
done
