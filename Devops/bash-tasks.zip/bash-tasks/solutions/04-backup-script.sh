#!/usr/bin/env bash
src="${1:-}"; dest="${2:-}"
usage() { echo "Usage: $0 SOURCE_DIR DEST_DIR" >&2; exit 2; }
[[ -n $src && -n $dest ]] || usage
[[ -d $src ]] || { echo "Source not found: $src" >&2; exit 1; }
mkdir -p "$dest"
stamp=$(date +%Y-%m-%d_%H%M%S)
archive="$dest/backup_${stamp}.tar.gz"
tar -czf "$archive" -C "$(dirname "$src")" "$(basename "$src")"
echo "Created $archive"
# keep only the newest 3 backups
ls -1 "$dest"/backup_*.tar.gz | sort -r | tail -n +4 | xargs -r rm --
