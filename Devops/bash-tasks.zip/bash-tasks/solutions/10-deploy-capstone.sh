#!/usr/bin/env bash
set -euo pipefail

LOG="deploy.log"
log()   { echo "$(date '+%Y-%m-%d %H:%M:%S') [$1] $2" | tee -a "$LOG"; }
usage() { echo "Usage: $0 -v VERSION [-e dev|staging|prod] [-d]" >&2; }

version=""; env="dev"; dry=false
while getopts "v:e:dh" opt; do
  case $opt in
    v) version=$OPTARG ;;
    e) env=$OPTARG ;;
    d) dry=true ;;
    h) usage; exit 0 ;;
    *) usage; exit 2 ;;
  esac
done

[[ -n $version ]] || { usage; exit 2; }
case $env in
  dev|staging|prod) ;;
  *) log ERROR "Invalid environment: $env"; exit 3 ;;
esac

release="releases/$version"
created=false
cleanup() {
  local code=$?
  if [[ $code -ne 0 && $created == true ]]; then
    log WARN "Deploy failed, rolling back $release"
    rm -rf "$release"
  fi
}
trap cleanup EXIT

log INFO "Deploy started: version=$version env=$env dry_run=$dry"
if $dry; then
  log INFO "[dry-run] would copy app/ to $release and point current -> $release"
  log INFO "Deploy finished (dry run)"
  exit 0
fi

[[ -d app ]] || { log ERROR "app/ directory missing"; exit 4; }
mkdir -p releases
[[ ! -e $release ]] || { log ERROR "Release $version already exists"; exit 5; }
cp -r app "$release"; created=true
echo "env=$env" > "$release/.env"
ln -sfn "$release" current
log INFO "Deploy finished: current -> $release"
