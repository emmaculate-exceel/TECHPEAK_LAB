#!/usr/bin/env bash
dir="${1:-}"; prefix="${2:-}"
[[ -n $dir && -n $prefix ]] || { echo "Usage: $0 DIR NEW_PREFIX" >&2; exit 2; }
[[ -d $dir ]] || { echo "Not a directory: $dir" >&2; exit 1; }
shopt -s nullglob
count=0
for f in "$dir"/IMG_*.JPG; do
  base="${f##*/}"
  num="${base#IMG_}"
  num="${num%.JPG}"
  mv -- "$f" "$dir/${prefix}_${num}.jpg"
  echo "$base -> ${prefix}_${num}.jpg"
  count=$((count + 1))
done
echo "Renamed $count file(s)"
