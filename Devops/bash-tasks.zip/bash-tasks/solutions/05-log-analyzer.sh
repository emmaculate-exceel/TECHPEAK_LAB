#!/usr/bin/env bash
log="${1:-}"
[[ -f $log ]] || { echo "Usage: $0 LOGFILE" >&2; exit 1; }
echo "Total requests: $(wc -l < "$log" | tr -d ' ')"
echo "404 errors: $(awk '$9==404' "$log" | wc -l | tr -d ' ')"
echo "500 errors: $(awk '$9==500' "$log" | wc -l | tr -d ' ')"
echo "Top IPs:"
awk '{print $1}' "$log" | sort | uniq -c | sort -rn | head -3
