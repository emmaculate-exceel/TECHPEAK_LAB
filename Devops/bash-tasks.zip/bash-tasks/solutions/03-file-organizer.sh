#!/usr/bin/env bash
dir="${1:-messy}"
[[ -d $dir ]] || { echo "Directory not found: $dir" >&2; exit 1; }
for f in "$dir"/*; do
  [[ -f $f ]] || continue
  ext="${f##*.}"; ext="${ext,,}"
  case $ext in
    jpg|jpeg|png|gif) target=images ;;
    txt|pdf|md|docx)  target=docs ;;
    *)                target=other ;;
  esac
  mkdir -p "$dir/$target"
  mv "$f" "$dir/$target/"
  echo "Moved $(basename "$f") -> $target/"
done
