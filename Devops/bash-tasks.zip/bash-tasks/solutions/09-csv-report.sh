#!/usr/bin/env bash
file="${1:-}"
[[ -f $file ]] || { echo "Usage: $0 CSVFILE" >&2; exit 1; }
declare -A total count
top_name=""; top_sal=0
{
  read -r _header
  while IFS=, read -r name dept salary; do
    total[$dept]=$(( ${total[$dept]:-0} + salary ))
    count[$dept]=$(( ${count[$dept]:-0} + 1 ))
    if (( salary > top_sal )); then top_sal=$salary; top_name=$name; fi
  done
} < "$file"
for d in $(printf '%s\n' "${!total[@]}" | sort); do
  echo "$d: ${count[$d]} employees, total ${total[$d]}"
done
echo "Highest paid: $top_name ($top_sal)"
