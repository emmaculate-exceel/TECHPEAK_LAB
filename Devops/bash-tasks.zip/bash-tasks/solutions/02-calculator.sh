#!/usr/bin/env bash
if [[ $# -ne 3 ]]; then
  echo "Usage: $0 NUM1 OP NUM2" >&2
  exit 2
fi
a=$1; op=$2; b=$3
case $op in
  +) echo $((a + b)) ;;
  -) echo $((a - b)) ;;
  '*'|x) echo $((a * b)) ;;
  /)
    if [[ $b -eq 0 ]]; then
      echo "Error: division by zero" >&2
      exit 1
    fi
    echo $((a / b)) ;;
  *) echo "Error: unknown operator '$op'" >&2; exit 2 ;;
esac
