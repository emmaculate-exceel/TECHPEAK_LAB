#!/usr/bin/env bash
report="${1:-report.txt}"

section()   { printf '\n== %s ==\n' "$1"; }
sys_info()  { section "System"; echo "Hostname: $(hostname)"; echo "Date: $(date)"; echo "Uptime: $(uptime -p 2>/dev/null || uptime)"; }
disk_info() { section "Disk usage"; df -h / | tail -n 1 | awk '{print "Used " $3 " of " $2 " (" $5 ")"}'; }
mem_info()  { section "Memory"; free -m | awk '/^Mem:/ {print "Used " $3 "MB of " $2 "MB"}'; }
load_info() { section "Load average"; cut -d' ' -f1-3 /proc/loadavg; }

{ sys_info; disk_info; mem_info; load_info; } > "$report"
echo "Report written to $report"
