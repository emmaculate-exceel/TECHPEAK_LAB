#!/usr/bin/env bash
# Teacher tool: runs every check against the reference solutions
cd "$(dirname "$0")"; fail=0
for d in tasks/*/; do
  n=$(basename "$d"); echo "=== $n"
  bash "$d/check.sh" "solutions/$n.sh" || fail=1
done
[[ $fail -eq 0 ]] && echo "ALL TASKS PASS" || { echo "SOME TASKS FAILED"; exit 1; }
