# Bash Scripting: 10 Hands-On Tasks

Ten tasks that build from "Hello, World" to a real deploy script. Each task has a student
handout and an **automatic checker**, so students get instant feedback.

| # | Task | Core concepts | Level |
|---|------|---------------|-------|
| 1 | Hello Script | shebang, variables, `$1`, defaults | Beginner |
| 2 | Calculator | arithmetic, `case`, exit codes | Beginner |
| 3 | File Organizer | `for` loops, globbing, `mv`, parameter expansion | Beginner |
| 4 | Backup Script | `tar`, `date`, functions, cleanup | Intermediate |
| 5 | Log Analyzer | pipes, `awk`, `sort`, `uniq` | Intermediate |
| 6 | Guessing Game | `while`, `read`, `$RANDOM`, regex | Intermediate |
| 7 | System Report | functions, redirection, system commands | Intermediate |
| 8 | Bulk Rename | parameter expansion, quoting | Intermediate |
| 9 | CSV Report | `IFS`, `read`, associative arrays | Advanced |
| 10 | Deploy Capstone | `getopts`, `trap`, `set -euo pipefail`, logging | Advanced |

## Folder layout
```
tasks/NN-name/README.md   Student handout
tasks/NN-name/setup.sh    Creates sample data (used by the checker; students run it too)
tasks/NN-name/check.sh    Auto-checker
solutions/NN-name.sh      Reference solutions (teacher only, do not hand out)
verify_all.sh             Runs every checker against the solutions
lib.sh                    Shared helper functions for the checkers
```

## How students use a task
1. Open `tasks/NN-name/README.md` and read the mission.
2. If the folder has a `setup.sh`, run `bash setup.sh` inside a practice folder to get the sample data.
3. Write the script, then `chmod +x script.sh`.
4. Test it with the checker:
   ```
   bash tasks/NN-name/check.sh path/to/your_script.sh
   ```
   The checker builds a fresh temporary workspace, runs the script and prints PASS/FAIL for each requirement.

## Teacher notes
- Run `bash verify_all.sh` once to confirm your environment works. It should end with `ALL TASKS PASS`.
- Hand out only `tasks/`, `lib.sh` and nothing from `solutions/`.
- Ask students to submit the checker's output as proof of completion.
- Suggested pace: 2 tasks per session (5 sessions), or one per day for a bootcamp.
- Requirements: **Linux, macOS or WSL**, Bash 4+ (Task 9 needs associative arrays; on macOS run `brew install bash`). Tasks 4 and 7 use Linux tools (`xargs -r`, `free`, `/proc`).

## Pairs well with
The Git projects: have students keep every script in a Git repo and commit after each task.
